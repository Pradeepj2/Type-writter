import React from 'react';
import './App.css';
import ParagraphDiv from './Component/ParagraphDiv';

function App() {
  return (
    <div>
    <ParagraphDiv/>
    </div>
  );
}

export default App;
